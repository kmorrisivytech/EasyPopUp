﻿""""
Author: Kyle Morris
Date Turned In: 3/5/25
Assignment: Module 8 Final Project Submission
App Name: Easy Pop Up
Docstring: A simple Tkinter-based POS system for small kitchens and food trucks.
Allows users to place orders, track daily sales, generate reports, and close out the day.
"""
import tkinter as tk
from tkinter import messagebox, PhotoImage
from collections import Counter

class EasyPopupApp:
    def __init__(self, root):
        """Initializes the main application window and loads resources."""
        self.root = root
        self.root.title("EasyPopup POS")
        self.total_sales = 0  # Tracks total sales for the day
        self.transactions = []  # Stores all transactions for the day
        
        # Load and resize images for menu items
        self.burger_image = PhotoImage(file="burger.png").subsample(5, 5)  # Scaled burger image
        self.chicken_image = PhotoImage(file="chicken_sandwich.png").subsample(5, 5)  # Scaled chicken sandwich image
        
        self.create_main_menu()

    def create_main_menu(self):
        """Creates the main menu window with navigation buttons."""
        for widget in self.root.winfo_children():  # Clear previous widgets
            widget.destroy()
        
        tk.Label(self.root, text="EasyPopup", font=("Arial", 16, "bold")).pack(pady=10)
        
        tk.Button(self.root, text="New Order", command=self.open_order_window).pack(pady=5)
        tk.Button(self.root, text="Reports", command=self.open_reports_window).pack(pady=5)
        tk.Button(self.root, text="Checkout", command=self.open_checkout_window).pack(pady=5)
        tk.Button(self.root, text="Exit", command=self.root.quit).pack(pady=5)
    
    def open_order_window(self):
        """Opens the order entry window where users can select items to order."""
        self.order_window = tk.Toplevel(self.root)
        self.order_window.title("New Order")
        tk.Label(self.order_window, text="Order Entry", font=("Arial", 14)).pack(pady=10)
        
        tk.Label(self.order_window, text="Select Item:").pack()
        
        # Create buttons for each menu item with associated images
        burger_button = tk.Button(self.order_window, image=self.burger_image, text="Burger ($15)", compound="top", command=lambda: self.add_item("Burger", 15))
        burger_button.pack(pady=5)
        
        chicken_button = tk.Button(self.order_window, image=self.chicken_image, text="Chicken Sandwich ($17)", compound="top", command=lambda: self.add_item("Chicken Sandwich", 17))
        chicken_button.pack(pady=5)
        
        tk.Button(self.order_window, text="Back", command=self.order_window.destroy).pack(pady=5)
    
    def add_item(self, item, price):
        """Adds an item to the transactions list and updates total sales."""
        if not isinstance(item, str) or not isinstance(price, (int, float)):
            messagebox.showerror("Error", "Invalid item or price")  # Input validation
            return
        
        self.transactions.append((item, price))  # Store transaction details
        self.total_sales += price  # Update total sales
        messagebox.showinfo("Item Added", f"Added {item} - ${price}")  # Confirm item addition
        
        if hasattr(self.order_window, 'destroy'):
            self.order_window.destroy()  # Close order window after selection
    
    def open_checkout_window(self):
        """Opens the checkout window displaying total sales and the option to close out the day."""
        self.checkout_window = tk.Toplevel(self.root)
        self.checkout_window.title("Checkout")
        tk.Label(self.checkout_window, text="Checkout Summary", font=("Arial", 14)).pack(pady=10)
        tk.Label(self.checkout_window, text=f"Total Sales: ${self.total_sales}", font=("Arial", 12)).pack(pady=5)
        
        tk.Button(self.checkout_window, text="Close Out Day", command=self.close_out_day).pack(pady=5)
        tk.Button(self.checkout_window, text="Back", command=self.checkout_window.destroy).pack(pady=5)
    
    def close_out_day(self):
        """Finalizes the sales for the day, resets totals, and clears transactions."""
        if self.total_sales <= 0:
            messagebox.showerror("Error", "No sales recorded for the day.")
            return
        
        # Generate sales report
        with open("daily_sales_report.txt", "w") as file:
            file.write(f"Total Sales for the Day: ${self.total_sales}\n")
            file.write("Items Sold:\n")
            item_counts = Counter(item for item, _ in self.transactions)
            for item, count in item_counts.items():
                file.write(f"{item}: {count}\n")
        
        messagebox.showinfo("Close Out", "Daily sales have been recorded and saved to daily_sales_report.txt. Closing out the day!")
        self.transactions.clear()  # Reset transactions
        self.total_sales = 0  # Reset total sales
        
        if hasattr(self.order_window, 'destroy'):
            self.order_window.destroy()
        if hasattr(self.checkout_window, 'destroy'):
            self.checkout_window.destroy()
    
    def open_reports_window(self):
        """Displays a summary of total sales and items sold for the day."""
        reports_window = tk.Toplevel(self.root)
        reports_window.title("Reports")
        tk.Label(reports_window, text="Daily Reports", font=("Arial", 14)).pack(pady=10)
        tk.Label(reports_window, text=f"Total Sales for the Day: ${self.total_sales}", font=("Arial", 12)).pack(pady=5)
        
        # Count number of each item sold
        item_counts = Counter(item for item, _ in self.transactions)
        transactions_text = "\n".join([f"{item}: {count}" for item, count in item_counts.items()])
        tk.Label(reports_window, text=f"Items Sold:\n{transactions_text}", font=("Arial", 12)).pack(pady=5)
        
        tk.Button(reports_window, text="Back", command=reports_window.destroy).pack(pady=5)

if __name__ == "__main__":
    root = tk.Tk()
    app = EasyPopupApp(root)
    root.mainloop()